from flask import Flask, render_template, request, redirect, url_for, flash, session
import cx_Oracle
import random

app = Flask(__name__)
app.secret_key = "clave_secreta"

# Configuración de la conexión a Oracle
def conectar_db(username, password):
    try:
        conn = cx_Oracle.connect(
            user=username,
            password=password,
            dsn=cx_Oracle.makedsn("localhost", 1521, service_name="XE")
        )
        print("Conexión exitosa a la base de datos.")
        return conn
    except cx_Oracle.DatabaseError as e:
        print(f"Error al conectar a la base de datos: {e}")
        return None

# Decorador para verificar rol de administrador
def requiere_admin(f):
    from functools import wraps
    @wraps(f)
    def decorador(*args, **kwargs):
        if session.get("rol") != "admin":
            flash("Acceso denegado. Solo administradores pueden realizar esta acción.", "danger")
            return redirect(url_for("index"))
        return f(*args, **kwargs)
    return decorador

# Determinar el rol del usuario
def obtener_rol(username):
    roles = {
        "ADMINISTRADOR_1": "admin",  # Aseguramos que ADMINISTRADOR_1 tenga el rol "admin"
        "DIGITADOR_1": "digitador",  # Aseguramos que el digitador tenga su rol adecuado
    }
    rol = roles.get(username, "consulta")  # Si el usuario no es admin ni digitador, tiene rol "consulta"
    print(f"Rol asignado para {username}: {rol}")  # Para depuración
    return rol

# Página de inicio de sesión
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"].upper().replace(".", "").replace("-", "")
        password = request.form["password"]

        conn = conectar_db(username, password)
        if conn:
            # Guardar datos en la sesión
            session["usuario"] = username
            session["password"] = password
            session["rol"] = obtener_rol(username)

            flash("Inicio de sesión exitoso.", "success")
            return redirect(url_for("index"))
        else:
            flash("Usuario o contraseña incorrectos.", "danger")

    return render_template("login.html")

# Página principal
@app.route("/index")
def index():
    if "usuario" not in session or "password" not in session:
        flash("Debes iniciar sesión primero.", "danger")
        return redirect(url_for("login"))

    conn = conectar_db(session["usuario"], session["password"])
    if conn:
        cursor = conn.cursor()
        query = """
        SELECT 
            l.BookID, l.Titulo, l.Precio, l.Stock, a.Nombre AS Autor, c.NombreCategoria AS Categoria
        FROM 
            SYSTEM.Libros l
        JOIN 
            SYSTEM.Autores a ON l.AuthorID = a.AuthorID
        JOIN 
            SYSTEM.Categorias c ON l.CategoryID = c.CategoryID
        """
        cursor.execute(query)
        libros = cursor.fetchall()
        conn.close()
        return render_template("index.html", libros=libros)
    else:
        flash("Error al conectar a la base de datos.", "danger")
        return redirect(url_for("login"))

# Página de registro de usuarios
@app.route("/registrar", methods=["GET", "POST"])
def registrar():
    if request.method == "POST":
        rut = request.form["rut"].replace(".", "").replace("-", "")
        nombre = request.form["nombre"]
        apellidos = request.form["apellidos"]
        contrasena = request.form["contrasena"]

        conn = conectar_db("ADMINISTRADOR_1", "admin123")
        if conn:
            cursor = conn.cursor()
            try:
                cursor.callproc("SYSTEM.INSERTAR_USUARIO", [rut, nombre, apellidos, contrasena])
                conn.commit()
                flash("Usuario registrado con éxito.", "success")
                return redirect(url_for("login"))
            except cx_Oracle.DatabaseError as e:
                flash(f"Error al registrar usuario: {e}", "danger")
            finally:
                conn.close()
        else:
            flash("Error al conectar a la base de datos.", "danger")

    return render_template("registrar.html")

# Ruta para agregar libros al carrito
@app.route("/agregar_carrito/<int:book_id>", methods=["POST"])
def agregar_carrito(book_id):
    if 'carrito' not in session:
        session['carrito'] = []

    # Agregar el libro al carrito
    session['carrito'].append(book_id)
    flash("Libro agregado al carrito.", "success")
    return redirect(url_for('index'))

# Página del carrito
@app.route("/carrito")
def carrito():
    if "usuario" not in session or "password" not in session:
        flash("Debes iniciar sesión primero.", "danger")
        return redirect(url_for("login"))

    if 'carrito' not in session or len(session['carrito']) == 0:
        flash("El carrito está vacío.", "info")
        return render_template("carrito.html", libros=[])

    # Obtener los libros del carrito
    conn = conectar_db(session["usuario"], session["password"])
    libros_carrito = []
    if conn:
        cursor = conn.cursor()
        for book_id in session['carrito']:
            cursor.execute("SELECT BookID, Titulo, Precio FROM SYSTEM.Libros WHERE BookID = :id", [book_id])
            libro = cursor.fetchone()
            if libro:
                libros_carrito.append(libro)
        conn.close()

    return render_template("carrito.html", libros=libros_carrito)

# Ruta para insertar productos (solo administradores)
@app.route("/insertar_producto", methods=["GET", "POST"])
@requiere_admin
def insertar_producto():
    if request.method == "POST":
        book_id = request.form["book_id"]
        titulo = request.form["titulo"]
        author_id = request.form["author_id"]
        category_id = request.form["category_id"]
        publisher_id = request.form["publisher_id"]
        precio = request.form["precio"]
        stock = request.form["stock"]

        conn = conectar_db(session["usuario"], session["password"])
        if conn:
            cursor = conn.cursor()
            try:
                # Insertar el nuevo libro en la base de datos
                cursor.callproc("insertar_libro", [book_id, titulo, author_id, category_id, publisher_id, precio, stock])
                conn.commit()
                flash("Libro registrado correctamente.", "success")
            except cx_Oracle.DatabaseError as e:
                flash(f"Error al registrar el libro: {e}", "danger")
            finally:
                conn.close()

            return redirect(url_for("index"))

    return render_template("insertar_producto.html")

# Ruta para modificar el precio de un libro (solo administradores)
@app.route("/modificar_precio", methods=["GET", "POST"])
@requiere_admin
def modificar_precio():
    if request.method == "POST":
        book_id = request.form["book_id"]
        nuevo_precio = request.form["nuevo_precio"]

        conn = conectar_db(session["usuario"], session["password"])
        if conn:
            cursor = conn.cursor()
            try:
                # Actualizar el precio del libro
                cursor.callproc("ACTUALIZAR_PRECIO_LIBRO", [book_id, nuevo_precio])
                conn.commit()
                flash("Precio actualizado correctamente.", "success")
            except cx_Oracle.DatabaseError as e:
                flash(f"Error al actualizar el precio: {e}", "danger")
            finally:
                conn.close()

            return redirect(url_for("index"))

    return render_template("modificar_precio.html")

# Ruta para borrar un libro (solo administradores)
@app.route("/borrar_libro", methods=["GET", "POST"])
@requiere_admin
def borrar_libro():
    if request.method == "POST":
        book_id = request.form["book_id"]

        conn = conectar_db(session["usuario"], session["password"])
        if conn:
            cursor = conn.cursor()
            try:
                # Borrar el libro de la base de datos
                cursor.callproc("borrar_libro", [book_id])
                conn.commit()
                flash("Libro borrado correctamente.", "success")
            except cx_Oracle.DatabaseError as e:
                flash(f"Error al borrar el libro: {e}", "danger")
            finally:
                conn.close()

            return redirect(url_for("index"))

    return render_template("borrar_libro.html")

# Página para ingresar los datos del cliente
@app.route("/informacion_cliente", methods=["POST", "GET"])
def informacion_cliente():
    if "carrito" not in session or len(session["carrito"]) == 0:
        flash("Tu carrito está vacío.", "warning")
        return redirect(url_for("index"))

    if request.method == "POST":
        nombre_cliente = request.form.get("nombre_cliente")
        direccion = request.form.get("direccion_cliente")
        telefono = request.form.get("telefono_cliente")
        medio_pago = request.form.get("medio_pago")

        if not nombre_cliente or not direccion or not telefono or not medio_pago:
            flash("Todos los campos son requeridos.", "warning")
            return redirect(url_for("informacion_cliente"))

        codigo_seguimiento = random.randint(1000000, 9999999)

        session['cliente'] = {
            'nombre': nombre_cliente,
            'direccion': direccion,
            'telefono': telefono,
            'medio_pago': medio_pago,
            'codigo_seguimiento': codigo_seguimiento
        }

        session.pop("carrito", None)

        flash("Compra realizada correctamente.", "success")
        return redirect(url_for("informacion_final"))

    return render_template("informacion_cliente.html")

# Finalizar compra
@app.route("/finalizar_compra", methods=["POST", "GET"])
def finalizar_compra():
    if "carrito" not in session or len(session["carrito"]) == 0:
        flash("Tu carrito está vacío.", "warning")
        return redirect(url_for("index"))

    carrito_libros = session["carrito"]
    total = 0
    libros_carrito = []
    conn = conectar_db(session["usuario"], session["password"])
    if conn:
        cursor = conn.cursor()
        for book_id in carrito_libros:
            cursor.execute("SELECT BookID, Titulo, Precio FROM SYSTEM.Libros WHERE BookID = :id", [book_id])
            libro = cursor.fetchone()
            if libro:
                libros_carrito.append(libro)
                total += libro[2]

        conn.close()

    return render_template("finalizar_compra.html", libros=libros_carrito, total=total)

# Página para mostrar la información del cliente y el código de seguimiento
@app.route("/informacion_final")
def informacion_final():
    if 'cliente' not in session:
        flash("No se encontró la información del cliente.", "danger")
        return redirect(url_for("index"))

    cliente = session['cliente']
    return render_template("informacion_final.html", cliente=cliente)

# Página de satisfacción
@app.route("/encuesta_satisfaccion", methods=["POST", "GET"])
def encuesta_satisfaccion():
    if request.method == "POST":
        puntuacion = request.form.get("puntuacion")
        comentario = request.form.get("comentario")

        flash("Gracias por tu retroalimentación.", "success")
        return redirect(url_for("agradecimiento"))

    return render_template("encuesta_satisfaccion.html")

# Página de agradecimiento
@app.route("/agradecimiento")
def agradecimiento():
    return render_template("agradecimiento.html")

# Cerrar sesión
@app.route("/cerrar_sesion")
def cerrar_sesion():
    session.clear()
    flash("Sesión cerrada correctamente.", "info")
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(debug=True)
