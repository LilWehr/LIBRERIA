from flask import Flask, render_template
import cx_Oracle

app = Flask(__name__)

# Configuración de la conexión a Oracle
def conectar_db():
    try:
        conn = cx_Oracle.connect(
            user="system",           # Cambia según tu configuración
            password="usuario",      # Cambia por tu contraseña
            dsn=cx_Oracle.makedsn("localhost", 1521, service_name="XE")
        )
        print("Conexión exitosa a la base de datos.")
        return conn
    except cx_Oracle.DatabaseError as e:
        print(f"Error al conectar a la base de datos: {e}")
        return None

# Ruta principal
@app.route("/")
def index():
    conn = conectar_db()
    if conn:
        cursor = conn.cursor()
        query = """
        SELECT l.BookID, l.Titulo, l.Precio, l.Stock, a.Nombre AS Autor, c.NombreCategoria AS Categoria
        FROM Libros l
        JOIN Autores a ON l.AuthorID = a.AuthorID
        JOIN Categorias c ON l.CategoryID = c.CategoryID
        """
        cursor.execute(query)
        libros = cursor.fetchall()
        print("Datos enviados al HTML:", libros)
        conn.close()
        return render_template("index.html", libros=libros)
    else:
        return "Error al conectar a la base de datos."

if __name__ == "__main__":
    app.run(debug=True)
