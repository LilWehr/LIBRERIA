import cx_Oracle

# Configuración de la conexión a Oracle
username = "system"
password = "usuario"
dsn = "localhost/XE"  # Cambia esto según tu configuración

try:
    # Crear conexión
    conn = cx_Oracle.connect(
        user=username,
        password=password,
        dsn=cx_Oracle.makedsn("localhost", 1521, service_name="XE")
    )
    cursor = conn.cursor()

    # CREACIÓN DE TABLAS
    tablas_sql = [
        """
        CREATE TABLE USUARIO (
            RUT NUMBER PRIMARY KEY,
            NOMBRE VARCHAR2(100),
            APELLIDOS VARCHAR2(100),
            CONTRASENA VARCHAR2(100)
        )""",
        """
        CREATE TABLE CATEGORIA (
            CODIGO NUMBER PRIMARY KEY,
            NOMBRE VARCHAR2(20)
        )""",
        """
        CREATE TABLE PRODUCTO (
            CODIGO NUMBER PRIMARY KEY,
            NOMBRE VARCHAR2(40),
            PRECIO NUMBER,
            CODIGO_CATEGORIA NUMBER,
            STOCK NUMBER,
            RUT_USUARIO NUMBER,
            FOREIGN KEY (CODIGO_CATEGORIA) REFERENCES CATEGORIA(CODIGO) ON DELETE CASCADE,
            FOREIGN KEY (RUT_USUARIO) REFERENCES USUARIO(RUT) ON DELETE CASCADE
        )"""
    ]

    for sql in tablas_sql:
        try:
            cursor.execute(sql)
            print("Tabla creada con éxito.")
        except cx_Oracle.DatabaseError as e:
            print(f"Error al crear la tabla: {e}")

    # INSERTAR DATOS
    datos_insercion = [
        "INSERT INTO CATEGORIA VALUES (1, 'PORTABLES')",
        "INSERT INTO CATEGORIA VALUES (2, 'TECNOLOGIA')",
        "INSERT INTO USUARIO VALUES (18575620, 'FELIPE', 'TAPIA', '1234')",
        """
        INSERT INTO PRODUCTO 
        VALUES (1, 'NOTEBOOK LENOVO', 380000, 1, 20, 18575620)
        """
    ]

    for data in datos_insercion:
        try:
            cursor.execute(data)
            print("Datos insertados correctamente.")
        except cx_Oracle.DatabaseError as e:
            print(f"Error al insertar datos: {e}")

    # CREAR FUNCIONES
    funciones_sql = [
        """
        CREATE OR REPLACE FUNCTION OBTENER_CONTRASENA(
            RUT_U IN USUARIO.RUT%TYPE
        ) RETURN VARCHAR2 IS
            CONTRASENA_ALMACENADA VARCHAR2(100);
        BEGIN
            SELECT CONTRASENA INTO CONTRASENA_ALMACENADA
            FROM USUARIO 
            WHERE RUT = RUT_U;
            RETURN CONTRASENA_ALMACENADA;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN RETURN 'FALSE';
            WHEN OTHERS THEN RETURN 'FALSE';
        END;
        """,
        """
        CREATE OR REPLACE FUNCTION VERIFICAR_USUARIO(
            RUT_U IN USUARIO.RUT%TYPE
        ) RETURN BOOLEAN IS
            CONTADOR NUMBER;
        BEGIN
            SELECT COUNT(*) INTO CONTADOR
            FROM USUARIO 
            WHERE RUT = RUT_U;
            RETURN CONTADOR > 0;
        EXCEPTION
            WHEN OTHERS THEN RETURN FALSE;
        END;
        """
    ]

    for func in funciones_sql:
        try:
            cursor.execute(func)
            print("Función creada correctamente.")
        except cx_Oracle.DatabaseError as e:
            print(f"Error al crear la función: {e}")

    # CREAR PROCEDIMIENTOS
    procedimientos_sql = [
        """
        CREATE OR REPLACE PROCEDURE INICIAR_SESION(
            RUT_USUARIO IN USUARIO.RUT%TYPE,
            CONTRASENA_USUARIO IN USUARIO.CONTRASENA%TYPE,
            RESULTADO OUT VARCHAR2,
            MENSAJE OUT VARCHAR2
        ) IS
            CONTRASENA_ALMACENADA VARCHAR2(100);
        BEGIN
            IF VERIFICAR_USUARIO(RUT_USUARIO) THEN
                CONTRASENA_ALMACENADA := OBTENER_CONTRASENA(RUT_USUARIO);
                IF CONTRASENA_USUARIO = CONTRASENA_ALMACENADA THEN
                    RESULTADO := 'TRUE';
                    MENSAJE := 'HA INICIADO SESIÓN EXITOSAMENTE';
                ELSE
                    RESULTADO := 'FALSE';
                    MENSAJE := 'CONTRASEÑA INCORRECTA';
                END IF;
            ELSE
                RESULTADO := 'FALSE';
                MENSAJE := 'USUARIO NO EXISTE';
            END IF;
        EXCEPTION
            WHEN OTHERS THEN
                RESULTADO := 'FALSE';
                MENSAJE := 'ERROR INTERNO: ' || SQLERRM;
        END;
        """,
        """
        CREATE OR REPLACE PROCEDURE INSERTAR_USUARIO(
            RUT_U IN USUARIO.RUT%TYPE,
            NOMBRE_U IN USUARIO.NOMBRE%TYPE,
            APELLIDOS_U IN USUARIO.APELLIDOS%TYPE,
            CONTRASENA_U IN USUARIO.CONTRASENA%TYPE,
            RESULTADO OUT VARCHAR2,
            MENSAJE OUT VARCHAR2
        ) IS
            USUARIO_EXISTE EXCEPTION;
        BEGIN
            LOCK TABLE USUARIO IN ROW EXCLUSIVE MODE;
            IF VERIFICAR_USUARIO(RUT_U) THEN
                RAISE USUARIO_EXISTE;
            ELSE
                INSERT INTO USUARIO 
                VALUES (RUT_U, NOMBRE_U, APELLIDOS_U, CONTRASENA_U);
                COMMIT;
                RESULTADO := 'TRUE';
                MENSAJE := 'USUARIO REGISTRADO EXITOSAMENTE';
            END IF;
        EXCEPTION
            WHEN USUARIO_EXISTE THEN
                RESULTADO := 'FALSE';
                MENSAJE := 'EL USUARIO YA EXISTE';
                ROLLBACK;
            WHEN OTHERS THEN
                RESULTADO := 'FALSE';
                MENSAJE := 'ERROR NO CONTROLADO: ' || SQLERRM;
                ROLLBACK;
        END;
        """
    ]

    for proc in procedimientos_sql:
        try:
            cursor.execute(proc)
            print("Procedimiento creado correctamente.")
        except cx_Oracle.DatabaseError as e:
            print(f"Error al crear el procedimiento: {e}")

    # CREAR TRIGGERS
    triggers_sql = [
        """
        CREATE OR REPLACE TRIGGER MAYUSCULA_USUARIO
        BEFORE INSERT ON USUARIO
        FOR EACH ROW
        BEGIN
            :NEW.NOMBRE := UPPER(:NEW.NOMBRE);
            :NEW.APELLIDOS := UPPER(:NEW.APELLIDOS);
        END;
        """,
        """
        CREATE OR REPLACE TRIGGER MAYUSCULA_PRODUCTO
        BEFORE INSERT ON PRODUCTO
        FOR EACH ROW
        BEGIN
            :NEW.NOMBRE := UPPER(:NEW.NOMBRE);
        END;
        """
    ]

    for trg in triggers_sql:
        try:
            cursor.execute(trg)
            print("Trigger creado correctamente.")
        except cx_Oracle.DatabaseError as e:
            print(f"Error al crear el trigger: {e}")

    conn.commit()

except cx_Oracle.DatabaseError as e:
    print(f"Error al ejecutar el script: {e}")

finally:
    if 'cursor' in locals() and cursor is not None:
        cursor.close()
    if 'conn' in locals() and conn is not None:
        conn.close()
