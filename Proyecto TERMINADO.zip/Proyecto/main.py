from flask import Flask, render_template, request, redirect, url_for, flash, session
import cx_Oracle
import random

app = Flask(__name__)
app.secret_key = "clave_secreta"

# Configuración de la conexión a Oracle
def conectar_bdd():
    try:    
        servidor = cx_Oracle.makedsn('localhost', '1521', service_name='xe') 
        conexion = cx_Oracle.connect(user='GERMAN', password='1234', dsn=servidor) 
        return conexion
    except cx_Oracle.DatabaseError as e:
        return False

def requiere_admin(f):
    from functools import wraps
    @wraps(f)
    def decorador(*args, **kwargs):
        if session.get("rol") != "admin":
            flash("Acceso denegado. Solo administradores pueden realizar esta acción.", "danger")
            return redirect(url_for("index"))
        return f(*args, **kwargs)
    return decorador
# Página de inicio de sesión
def requiere_admin_o_digitador(f):
    from functools import wraps
    @wraps(f)
    def decorador(*args, **kwargs):
        if session.get("rol") not in ["admin", "digitador"]:
            flash("Acceso denegado. Solo administradores o digitadores pueden realizar esta acción.", "danger")
            return redirect(url_for("index"))
        return f(*args, **kwargs)
    return decorador
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"].replace(".", "").replace("-", "")
        password = request.form["password"]

        print(f"Username: {username}, Password: {password}")  # Depuración

        conn = conectar_bdd()
        if conn:
            cursor = conn.cursor()
            try:
                cursor.execute("""
                    SELECT Nombre, Contrasena
                    FROM USUARIOS
                    WHERE Nombre = :username AND Contrasena = :password
                """, {"username": username, "password": password})
                result = cursor.fetchone()
                if result:
                    print("Usuario encontrado en la base de datos")  # Depuración
                    # Obtener el rol del usuario
                    cursor.execute("""
                        SELECT Rol
                        FROM USUARIOS
                        WHERE Nombre = :username AND Contrasena = :password
                    """, {"username": username, "password": password})
                    rol_result = cursor.fetchone()
                    rol = rol_result[0] if rol_result else "usuario"

                    session["usuario"] = username
                    session["password"] = password
                    session["rol"] = rol

                    flash("Inicio de sesión exitoso.", "success")
                    return redirect(url_for("index"))
                else:
                    print("Usuario o contraseña incorrectos")  # Depuración
                    flash("Usuario o contraseña incorrectos.", "danger")
            except cx_Oracle.DatabaseError as e:
                print(f"Error al iniciar sesión: {e}")  # Depuración
                flash(f"Error al iniciar sesión: {e}", "danger")
            finally:
                cursor.close()
                conn.close()

    return render_template("login.html")

# Página principal
@app.route("/index")
def index():
    if "usuario" not in session or "password" not in session:
        flash("Debes iniciar sesión primero.", "danger")
        return redirect(url_for("login"))

    conn = conectar_bdd()
    if conn:
        cursor = conn.cursor()
        query = """
        SELECT 
            BookID, Titulo, Precio, Stock, AuthorID, CategoryID, PublisherID, url_imagen
        FROM 
            LIBROS
        """
        cursor.execute(query)
        libros = cursor.fetchall()
        conn.close()
        rol = session.get("rol")
        if rol == "usuario":
            return render_template("index_usuario.html", libros=libros, rol=rol)
        else:
            return render_template("index.html", libros=libros, rol=rol)
    else:
        flash("Error al conectar a la base de datos.", "danger")
        return redirect(url_for("login"))
# Página de registro de usuarios
@app.route("/registrar", methods=["GET", "POST"])
def registrar():
    if request.method == "POST":
        rut = request.form["rut"].replace(".", "").replace("-", "")
        nombre = request.form["nombre"]
        apellidos = request.form["apellidos"]
        contrasena = request.form["contrasena"]
        rol = "usuario"  # Asignar el rol 'usuario' por defecto

        conn = conectar_bdd()
        if conn:
            cursor = conn.cursor()
            try:
                # Inserción directa usando una consulta SQL
                cursor.execute("""
                    INSERT INTO USUARIOS (Rut, Nombre, Apellidos, Contrasena, Rol)
                    VALUES (:rut, :nombre, :apellidos, :contrasena, :rol)
                """, rut=rut, nombre=nombre, apellidos=apellidos, contrasena=contrasena, rol=rol)
                conn.commit()
                flash("Usuario registrado con éxito.", "success")
                return redirect(url_for("login"))
            except cx_Oracle.DatabaseError as e:
                flash(f"Error al registrar usuario: {e}", "danger")
            finally:
                cursor.close()
                conn.close()
        else:
            flash("Error al conectar a la base de datos.", "danger")

    return render_template("registrar.html")

# Ruta para agregar libros al carrito
@app.route("/agregar_carrito/<int:book_id>", methods=["POST"])
def agregar_carrito(book_id):
    if 'carrito' not in session:
        session['carrito'] = []

    # Agregar el libro al carrito
    session['carrito'].append(book_id)
    flash("Libro agregado al carrito.", "success")
    return redirect(url_for('index'))


# Ruta para insertar productos (solo administradores)
@app.route("/insertar_producto", methods=["GET", "POST"])
@requiere_admin
def insertar_producto():
    if request.method == "POST":
        book_id = request.form["book_id"]
        titulo = request.form["titulo"]
        author_id = request.form["author_id"]
        category_id = request.form["category_id"]
        publisher_id = request.form["publisher_id"]
        precio = request.form["precio"]
        stock = request.form["stock"]
        url_imagen = request.form["url_imagen"]

        conn = conectar_bdd()
        if conn:
            cursor = conn.cursor()
            try:
                # Insertar el nuevo libro en la base de datos
                cursor.execute("""
                    INSERT INTO LIBROS (BookID, Titulo, AuthorID, CategoryID, PublisherID, Precio, Stock, url_imagen)
                    VALUES (:book_id, :titulo, :author_id, :category_id, :publisher_id, :precio, :stock, :url_imagen)
                """, {
                    'book_id': book_id,
                    'titulo': titulo,
                    'author_id': author_id,
                    'category_id': category_id,
                    'publisher_id': publisher_id,
                    'precio': precio,
                    'stock': stock,
                    'url_imagen': url_imagen
                })
                conn.commit()
                flash("Libro registrado correctamente.", "success")
            except cx_Oracle.DatabaseError as e:
                flash(f"Error al registrar el libro: {e}", "danger")
            finally:
                cursor.close()
                conn.close()

            return redirect(url_for("index"))

    return render_template("insertar_producto.html")

# Ruta para modificar el precio de un libro (solo administradores)
@app.route("/modificar_precio", methods=["GET", "POST"])
@requiere_admin_o_digitador
def modificar_precio():
    if request.method == "POST":
        book_id = request.form["book_id"]
        nuevo_precio = request.form["nuevo_precio"]

        conn = conectar_bdd()
        if conn:
            cursor = conn.cursor()
            try:
                # Actualizar el precio del libro usando una consulta SQL
                cursor.execute("""
                    UPDATE LIBROS
                    SET Precio = :nuevo_precio
                    WHERE BookID = :book_id
                """, nuevo_precio=nuevo_precio, book_id=book_id)
                conn.commit()
                flash("Precio actualizado correctamente.", "success")
            except cx_Oracle.DatabaseError as e:
                flash(f"Error al actualizar el precio: {e}", "danger")
            finally:
                cursor.close()
                conn.close()

            return redirect(url_for("index"))

    return render_template("modificar_precio.html")

@app.route("/modificar_stock", methods=["GET", "POST"])
@requiere_admin_o_digitador
def modificar_stock():
    if request.method == "POST":
        book_id = request.form["book_id"]
        nuevo_stock = request.form["nuevo_stock"]

        conn = conectar_bdd()
        if conn:
            cursor = conn.cursor()
            try:
                # Actualizar el precio del libro usando una consulta SQL
                cursor.execute("""
                    UPDATE LIBROS
                    SET Stock = :nuevo_stock
                    WHERE BookID = :book_id
                """, nuevo_stock=nuevo_stock, book_id=book_id)
                conn.commit()
                flash("Actualizado correctamente.", "success")
            except cx_Oracle.DatabaseError as e:
                flash(f"Error al actualizar el stock: {e}", "danger")
            finally:
                cursor.close()
                conn.close()

            return redirect(url_for("index"))

    return render_template("modificar_stock.html")
# Ruta para borrar un libro (solo administradores)
@app.route("/borrar_libro", methods=["GET", "POST"])
@requiere_admin
def borrar_libro():
    if request.method == "POST":
        book_id = request.form["book_id"]

        conn = conectar_bdd()
        if conn:
            cursor = conn.cursor()
            try:
                # Borrar el libro de la base de datos
                cursor.callproc("borrar_libro", [book_id])
                conn.commit()
                flash("Libro borrado correctamente.", "success")
            except cx_Oracle.DatabaseError as e:
                flash(f"Error al borrar el libro: {e}", "danger")
            finally:
                conn.close()

            return redirect(url_for("index"))

    return render_template("borrar_libro.html")



@app.route("/carrito", methods=["GET", "POST"])
def carrito():
    if "usuario" not in session or "password" not in session:
        flash("Debes iniciar sesión primero.", "danger")
        return redirect(url_for("login"))

    if 'carrito' not in session or len(session['carrito']) == 0:
        flash("El carrito está vacío.", "info")
        return render_template("carrito.html", libros=[], total=0)

    # Obtener los libros del carrito
    conn = conectar_bdd()
    libros_carrito = []
    total = 0
    if conn:
        cursor = conn.cursor()
        for book_id in session['carrito']:
            cursor.execute("SELECT BookID, Titulo, Precio FROM Libros WHERE BookID = :id", {'id': book_id})
            libro = cursor.fetchone()
            if libro:
                libros_carrito.append(libro)
                total += libro[2]

        if request.method == "POST":
            # Obtener los datos del formulario
            nombre_cliente = session["usuario"]  # Usar el nombre de usuario como nombre del cliente
            direccion = request.form.get("direccion_cliente")
            telefono = request.form.get("telefono_cliente")
            medio_pago = request.form.get("medio_pago")

            # Verificar que todos los campos estén completos
            if not direccion or not telefono or not medio_pago:
                flash("Todos los campos son requeridos.", "warning")
                return redirect(url_for("carrito"))

            # Generar un código de seguimiento aleatorio de 7 dígitos
            codigo_seguimiento = random.randint(1000000, 9999999)

            # Guardar esta información en la sesión
            session['cliente'] = {
                'nombre': nombre_cliente,
                'direccion': direccion,
                'telefono': telefono,
                'medio_pago': medio_pago,
                'codigo_seguimiento': codigo_seguimiento,
                'total': total
            }

            try:
                # Insertar los datos del cliente en la base de datos
                cursor.execute("""
                    INSERT INTO CLIENTE (nombre, direccion, telefono, medio_pago, codigo_seguimiento, total)
                    VALUES (:nombre, :direccion, :telefono, :medio_pago, :codigo_seguimiento, :total)
                """, {
                    'nombre': nombre_cliente,
                    'direccion': direccion,
                    'telefono': telefono,
                    'medio_pago': medio_pago,
                    'codigo_seguimiento': codigo_seguimiento,
                    'total': total
                })

                # Disminuir el stock de los libros comprados
                for book_id in session['carrito']:
                    cursor.execute("""
                        UPDATE LIBROS
                        SET STOCK = STOCK - 1
                        WHERE BookID = :id
                    """, {'id': book_id})

                conn.commit()  # Confirmar la transacción
                flash("Compra realizada correctamente.", "success")
            except cx_Oracle.DatabaseError as e:
                flash(f"Error al procesar la compra: {e}", "danger")
                conn.rollback()  # Deshacer en caso de error
            finally:
                cursor.close()
                conn.close()

            # Almacenar el total en la sesión
            session["total_compra"] = total

            # Limpiar el carrito
            session.pop("carrito", None)

            # Redirigir a la página de confirmación de compra
            return redirect(url_for("confirmacion_compra"))

        cursor.close()
        conn.close()

    return render_template("carrito.html", libros=libros_carrito, total=total, username=session["usuario"])

# Página de confirmación de compra
@app.route("/confirmacion_compra")
def confirmacion_compra():
    if 'cliente' not in session:
        flash("No se encontró la información del cliente.", "danger")
        return redirect(url_for("index"))

    cliente = session['cliente']
    total = session.get("total_compra", 0)  # Obtener el total de la sesión, por defecto 0 si no existe

    return render_template("informacion_final.html", cliente=cliente, total=total)

@app.route("/encuesta_satisfaccion", methods=["POST", "GET"])
def encuesta_satisfaccion():
    if request.method == "POST":
        satisfaccion = request.form.get("puntuacion")
        comentario = request.form.get("comentario")
        cliente = session.get('cliente', {})
        codigo_seguimiento = cliente.get('codigo_seguimiento')

        if not codigo_seguimiento:
            flash("No se encontró el código de seguimiento.", "danger")
            return redirect(url_for("index"))

        conn = conectar_bdd()
        if conn:
            cursor = conn.cursor()
            try:
                # Insertar los datos de la encuesta en la tabla ENCUESTA
                cursor.execute("""
                    INSERT INTO ENCUESTA (compraid, satisfaccion, comentario)
                    VALUES (:compraid, :satisfaccion, :comentario)
                """, {
                    'compraid': codigo_seguimiento,
                    'satisfaccion': satisfaccion,
                    'comentario': comentario
                })
                conn.commit()  # Confirmar la transacción
                flash("Gracias por tu retroalimentación.", "success")
            except cx_Oracle.DatabaseError as e:
                flash(f"Error al guardar la encuesta: {e}", "danger")
                conn.rollback()  # Deshacer en caso de error
            finally:
                cursor.close()
                conn.close()

            return redirect(url_for("agradecimiento"))

    return render_template("encuesta_satisfaccion.html")

    return render_template("encuesta_satisfaccion.html")
@app.route("/agradecimiento") 
def agradecimiento(): 
    return render_template("agradecimiento.html")
@app.route("/cerrar_sesion")
def cerrar_sesion():
    session.clear()
    flash("Sesión cerrada correctamente.", "info")
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(debug=True)